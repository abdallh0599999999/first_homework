package com.example.hom;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.hom.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
private int count =0;
    public static ActivityMainBinding mainBinding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());

       // setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.text_display_count), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void show_toast(View view){
        Toast.makeText(this, R.string.hello_abedallh_qweader, Toast.LENGTH_SHORT).show();
    }
    public void show_increas(View view){
        count ++;
        mainBinding.textDisplayCount.setText(String.valueOf(count));
    }
    public void to_Zero(View view){
        count =0;
        mainBinding.textDisplayCount.setText(String.valueOf(count));
     Toast.makeText(this, "The counteris Zero", Toast.LENGTH_SHORT).show();
    }


}